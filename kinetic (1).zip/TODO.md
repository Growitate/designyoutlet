# TODO

## Premium 3D agency experience
- [x] Deliver a premium design-agency website with a cinematic landing hero, interactive 3D artwork, kinetic typography, and a clear agency positioning statement.
- [x] Add scroll-driven scene transitions with parallax, depth, reveals, and synchronized motion graphics.
- [x] Present selected work through animated project cards and immersive case-study previews.
- [x] Present agency services through motion-led visual storytelling.
- [x] Add an expressive about/studio philosophy section with layered 3D composition.
- [x] Add a polished credibility section with client logos, testimonials, or recognition.
- [x] Close with a strong contact call-to-action and inquiry form.
- [x] Ensure responsive layouts and touch-friendly motion behavior across desktop, tablet, and mobile.
- [x] Make the animation system performance-conscious and include reduced-motion accessibility support.
- [x] Keep all navigation and interactions usable in the final preview.

Evidence: `npm run build` passes; homepage, route manifest, desktop viewport, mobile viewport, and full-page layout verified in the live preview.
