import { useEffect, useRef, useState } from 'react'
import { motion, useMotionValue, useScroll, useSpring, useTransform, AnimatePresence } from 'framer-motion'
import { ArrowDownRight, ArrowUpRight, CircleArrowOutUpRight, Menu, Plus, Send, Sparkles, Volume2, X } from 'lucide-react'

const projects = [
  { number: '01', client: 'Identity / Visual systems', title: 'Make it yours.', tag: 'Brand identity', color: 'acid', object: 'mountain', image: '/manus-storage/async-images/N2fAAVE3ZrFsPJPy3XfG05/image-1.webp' },
  { number: '02', client: 'Posters / Editorial design', title: 'Make it loud.', tag: 'Poster system', color: 'coral', object: 'disc', image: '/manus-storage/async-images/N2fAAVE3ZrFsPJPy3XfG05/image-2.webp' },
  { number: '03', client: 'Digital / Art direction', title: 'Make it move.', tag: 'Digital world', color: 'lilac', object: 'orb', image: '/manus-storage/async-images/N2fAAVE3ZrFsPJPy3XfG05/image-3.webp' },
]

const services = [
  ['01', 'Identity', 'Build a visual language people recognise instantly.'],
  ['02', 'Typography', 'Make every letter, layout and detail feel intentional.'],
  ['03', 'Art direction', 'Shape a distinct world across print, digital and culture.'],
  ['04', 'Digital design', 'Turn the visual system into engaging digital experiences.'],
]

const capabilities = ['IDENTITY', 'TYPOGRAPHY', 'POSTERS', 'PACKAGING', 'DIGITAL', 'ART DIRECTION']

function Reveal({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div className={className} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  )
}

function SceneObject({ type, color }: { type: string; color: string }) {
  return (
    <div className={`scene-object scene-${type} scene-${color}`} aria-hidden="true">
      {type === 'mountain' && <><div className="mountain-face mountain-face-a" /><div className="mountain-face mountain-face-b" /><div className="mountain-snow" /></>}
      {type === 'disc' && <><div className="disc-ring disc-ring-a" /><div className="disc-ring disc-ring-b" /><div className="disc-center" /></>}
      {type === 'orb' && <><div className="orb-core" /><div className="orb-ring orb-ring-a" /><div className="orb-ring orb-ring-b" /></>}
    </div>
  )
}

function DesignArtifact() {
  return (
    <div className="design-artifact" aria-hidden="true">
      <div className="artifact-shadow" />
      <div className="artifact-sheet artifact-sheet-back"><span>GRID<br />/ 03</span></div>
      <div className="artifact-sheet artifact-sheet-mid"><span className="artifact-crosshair">+</span><span className="artifact-type-small">DESIGNY<br />OUTLET</span><span className="artifact-rule" /></div>
      <div className="artifact-sheet artifact-sheet-front"><span className="artifact-index">01 / 24</span><strong>Aa</strong><span className="artifact-type">TYPE<br />SYSTEM</span><div className="artifact-swatch-row"><i /><i /><i /><i /></div><span className="artifact-crop crop-tl" /><span className="artifact-crop crop-br" /></div>
      <div className="artifact-pencil"><span /></div>
      <div className="artifact-orbit artifact-orbit-a" /><div className="artifact-orbit artifact-orbit-b" />
    </div>
  )
}

function PencilSoundControl() {
  const [enabled, setEnabled] = useState(false)
  const playScratch = () => {
    if (enabled) return
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AudioContextClass) return
    const context = new AudioContextClass()
    const buffer = context.createBuffer(1, context.sampleRate * 2, context.sampleRate)
    const data = buffer.getChannelData(0)
    for (let index = 0; index < data.length; index += 1) data[index] = (Math.random() * 2 - 1) * (0.42 + Math.sin(index / 19) * 0.08)
    const source = context.createBufferSource()
    const filter = context.createBiquadFilter()
    const gain = context.createGain()
    source.buffer = buffer
    source.loop = true
    filter.type = 'bandpass'
    filter.frequency.value = 2350
    filter.Q.value = 0.8
    gain.gain.setValueAtTime(0.0001, context.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.025, context.currentTime + 0.35)
    gain.gain.setValueAtTime(0.025, context.currentTime + 4.35)
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 5.1)
    source.connect(filter).connect(gain).connect(context.destination)
    source.start()
    source.stop(context.currentTime + 5.2)
    setEnabled(true)
  }

  return <button className="intro-sound" type="button" onPointerDown={playScratch}><Volume2 size={13} /> {enabled ? 'Pencil sound on' : 'Enable pencil sound'}</button>
}

function BrandIntro() {
  return (
    <motion.div className="brand-intro" initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}>
      <div className="brand-intro-red" />
      <motion.div className="intro-paper" initial={{ opacity: 0, y: 80, rotate: -4, scale: .86 }} animate={{ opacity: 1, y: 0, rotate: -2, scale: 1 }} transition={{ duration: .95, delay: .2, ease: [0.22, 1, 0.36, 1] }}>
        <div className="intro-paper-grain" />
        <svg className="intro-paper-svg" viewBox="0 0 900 520" fill="none">
          <defs><filter id="intro-paper-noise"><feTurbulence type="fractalNoise" baseFrequency=".8" numOctaves="3" stitchTiles="stitch" /><feColorMatrix type="saturate" values="0" /></filter></defs>
          <rect width="900" height="520" filter="url(#intro-paper-noise)" opacity=".05" />
          <path className="intro-paper-grid" d="M70 92H830 M70 126H830 M70 160H830 M70 194H830 M70 228H830 M70 262H830 M70 296H830 M70 330H830 M70 364H830 M70 398H830 M70 432H830" />
          <path className="intro-paper-grid" d="M95 70V450 M129 70V450 M163 70V450 M197 70V450 M231 70V450 M265 70V450 M299 70V450 M333 70V450 M367 70V450 M401 70V450 M435 70V450 M469 70V450 M503 70V450 M537 70V450 M571 70V450 M605 70V450 M639 70V450 M673 70V450 M707 70V450 M741 70V450 M775 70V450" />
          <motion.text className="intro-brand-writing" x="88" y="300" initial={{ strokeDashoffset: 1400, opacity: .1 }} animate={{ strokeDashoffset: 0, opacity: 1 }} transition={{ duration: 2.4, delay: 1.35, ease: 'easeInOut' }}>designy outlet.</motion.text>
          <motion.path className="intro-underline" d="M92 330 C270 352 540 343 808 323" initial={{ pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 1 }} transition={{ duration: 1.1, delay: 3.45, ease: 'easeInOut' }} />
          <path className="intro-paper-crop" d="M58 70H88 M73 55V85 M812 435H842 M827 420V450" />
        </svg>
        <motion.div className="intro-pencil" initial={{ x: -110, y: 18, rotate: -29 }} animate={{ x: [-110, -72, 16, 126, 262, 410, 558, 700, 820, 770], y: [18, 67, 122, 163, 171, 157, 164, 187, 230, 285], rotate: [-29, -22, -15, -8, -4, 0, 7, 16, 30, 42] }} transition={{ duration: 5.2, delay: .8, times: [0, .08, .18, .3, .44, .58, .72, .84, .94, 1], ease: 'easeInOut' }}><span className="intro-pencil-body" /><span className="intro-pencil-tip" /><span className="intro-pencil-eraser" /></motion.div>
        <div className="intro-paper-label"><span>DESIGNY OUTLET / 001</span><span>GRAPHIC DESIGN STUDIO</span></div>
      </motion.div>
      <motion.div className="intro-kicker" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .55, duration: .7 }}><span>DRAWING A POINT OF VIEW</span><i /></motion.div>
      <PencilSoundControl />
    </motion.div>
  )
}

function App() {
  const heroRef = useRef<HTMLElement>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeService, setActiveService] = useState(2)
  const [sent, setSent] = useState(false)
  const [introVisible, setIntroVisible] = useState(true)
  const { scrollYProgress } = useScroll()
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 80, damping: 24, restDelta: 0.001 })
  const pointerX = useMotionValue(0)
  const pointerSpringX = useSpring(pointerX, { stiffness: 90, damping: 20, mass: 0.7 })
  const heroOrbY = useTransform(scrollYProgress, [0, 0.35], [0, 210])
  const heroOrbRotate = useTransform(scrollYProgress, [0, 1], [-12, 55])
  const heroOrbScale = useTransform(scrollYProgress, [0, 0.35], [1, 1.08])
  const heroEditorialScrollX = useTransform(scrollYProgress, [0, 0.4], [0, 90])
  const heroEditorialX = useTransform([heroEditorialScrollX, pointerSpringX], ([scrollX, cursorX]) => Number(scrollX) + Number(cursorX) * 0.35)
  const heroObjectX = useTransform(pointerSpringX, [-32, 32], [-18, 18])
  const heroObjectTilt = useTransform(pointerSpringX, [-32, 32], [-4, 4])
  const heroCopyY = useTransform(scrollYProgress, [0, 0.32], [0, -100])

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduced) {
      setIntroVisible(false)
      return
    }
    const timer = window.setTimeout(() => setIntroVisible(false), 9000)
    return () => window.clearTimeout(timer)
  }, [])

  const handleHeroPointer = (event: React.PointerEvent<HTMLElement>) => {
    if (event.pointerType === 'touch') return
    const bounds = event.currentTarget.getBoundingClientRect()
    pointerX.set(((event.clientX - bounds.left) / bounds.width - 0.5) * 64)
  }

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  const replayIntro = () => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })
    setIntroVisible(false)
    window.setTimeout(() => setIntroVisible(true), 40)
  }

  return (
    <div className="site-shell">
      <AnimatePresence>{introVisible && <BrandIntro />}</AnimatePresence>
      <motion.div className="progress-line" style={{ scaleX: smoothProgress }} />
      <header className="topbar">
        <button className="wordmark" onClick={() => scrollTo('top')} aria-label="Back to top">
          <span className="wordmark-mark"><span /><span /><span /></span>
          <span>designy<span className="wordmark-dot"> outlet.</span></span>
        </button>
        <nav className={`main-nav ${menuOpen ? 'nav-open' : ''}`} aria-label="Primary navigation">
          <button onClick={() => scrollTo('work')}>Work</button>
          <button onClick={() => scrollTo('studio')}>About</button>
          <button onClick={() => scrollTo('services')}>Services</button>
          <button className="nav-contact" onClick={() => scrollTo('contact')}>Ready to stand out? <ArrowUpRight size={15} /></button>
        </nav>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
      </header>

      <main>
        <section className={`hero ${introVisible ? 'hero-intro-active' : ''}`} id="top" ref={heroRef} onPointerMove={handleHeroPointer} onPointerLeave={() => pointerX.set(0)}>
          <div className="hero-noise" /><div className="hero-grid" /><motion.div className="hero-editorial" style={{ x: heroEditorialX }} initial={{ opacity: 0, scale: 1.08 }} animate={{ opacity: 0.56, scale: 1 }} transition={{ duration: 1.2, delay: 0.25 }}><img src="/manus-storage/async-images/N2fAAVE3ZrFsPJPy3XfG05/image-1.webp" alt="Abstract red and black Designy Outlet campaign composition" /></motion.div>
          <div className="hero-graphics" aria-hidden="true"><span className="hero-cross cross-a" /><span className="hero-cross cross-b" /><span className="hero-particle particle-a" /><span className="hero-particle particle-b" /><span className="hero-particle particle-c" /><motion.div className="hero-sweep sweep-a" animate={{ rotate: [18, 27, 18], x: [0, 18, 0], opacity: [0.28, 0.62, 0.28] }} transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }} /><motion.div className="hero-sweep sweep-b" animate={{ rotate: [-24, -16, -24], x: [0, -24, 0], opacity: [0.18, 0.42, 0.18] }} transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay: 1.2 }} /><motion.div className="hero-scanline" animate={{ y: ['-20vh', '120vh'] }} transition={{ duration: 8, repeat: Infinity, ease: 'linear', delay: 1 }} /></div>
          <motion.div className="hero-copy" style={{ y: heroCopyY }}>
            <Reveal className="eyebrow"><span className="eyebrow-dot" /> Designy Outlet / Graphic design studio</Reveal>
            <h1><span className="display-line">Brands that don’t</span><span className="display-line display-indent"><em>blend in.</em><span className="display-cursor">_</span></span></h1>
            <div className="hero-bottom">
              <Reveal delay={0.15} className="hero-statement">We build identities, posters and digital worlds<br />for brands with something to say.</Reveal>
              <Reveal delay={0.25} className="scroll-cue"><span>Explore our approach</span><ArrowDownRight size={18} /></Reveal>
            </div>
          </motion.div>
          <motion.div className="hero-object-wrap" style={{ x: heroObjectX, y: heroOrbY, rotate: heroOrbRotate, rotateY: heroObjectTilt, scale: heroOrbScale }}><DesignArtifact /></motion.div>
          <div className="hero-microcopy">Scroll / 001 — 006</div>
        </section>

        <section className="ticker-section" aria-label="Designy Outlet statement"><div className="ticker-track">{Array.from({ length: 2 }).map((_, index) => <div className="ticker-item" key={index}>Graphic design with a point of view <span>✳</span> Brands that don’t blend in <span>✳</span></div>)}</div></section>

        <section className="manifesto section-paper">
          <div className="manifesto-aside"><span>( 01 )</span><span>Our point of view</span></div>
          <div className="manifesto-content">
            <Reveal><p className="kicker">Creativity with a strategy</p></Reveal>
            <Reveal delay={0.08}><h2>Make your brand<br /><span>impossible to <i>ignore.</i></span></h2></Reveal>
            <Reveal delay={0.16} className="manifesto-support"><p>Good design is more than being louder. We turn ideas into clear, memorable visual systems that people recognise and remember.</p><button className="text-link" onClick={() => scrollTo('studio')}>Our story <ArrowUpRight size={15} /></button></Reveal>
          </div>
          <div className="manifesto-orbit" aria-hidden="true"><div /><div /><div /></div>
        </section>

        <section className="work-section section-ink" id="work">
          <div className="section-head"><Reveal><p className="kicker light">What we make / Identity to image</p></Reveal><Reveal delay={0.08}><h2>Work that<br /><span>shapes culture.</span></h2></Reveal><Reveal delay={0.16} className="section-intro light-text"><p>Visual systems with a point of view. From the first sketch to the final export, every detail earns its place.</p></Reveal></div>
          <div className="project-stack">{projects.map((project, index) => <motion.article className={`project-card project-${project.color}`} key={project.number} whileHover={{ y: -10 }} transition={{ duration: 0.35 }}><div className="project-meta"><span>{project.number}</span><span>{project.client}</span><span>{project.tag}</span></div><div className="project-title"><h3>{project.title}</h3><ArrowUpRight size={24} /></div><div className="project-art">{project.image && <motion.img className="project-photo" src={project.image} alt="" initial={{ scale: 1.12, opacity: 0 }} whileInView={{ scale: 1, opacity: 0.78 }} viewport={{ once: true, amount: 0.35 }} transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }} />}{project.image && <div className="project-photo-wash" />}<SceneObject type={project.object} color={project.color} /><div className="project-coordinate">{String(index + 4).padStart(2, '0')}° 41’ 12” N</div></div><div className="project-footer"><span>Explore capability</span><span className="project-arrow"><ArrowUpRight size={16} /></span></div></motion.article>)}</div>
          <div className="work-foot"><span>Creative, strategic, measurable</span><CircleArrowOutUpRight size={16} /></div>
        </section>

        <section className="services-section section-paper" id="services">
          <div className="section-head services-head"><Reveal><p className="kicker">What we do</p></Reveal><Reveal delay={0.08}><h2>One eye.<br /><span>Many formats.</span></h2></Reveal><Reveal delay={0.16} className="section-intro"><p>Identity, typography and art direction working as one visual language across every surface.</p></Reveal></div>
          <div className="services-grid"><div className="service-list">{services.map(([number, title, description], index) => <button className={`service-row ${activeService === index ? 'is-active' : ''}`} key={number} onClick={() => setActiveService(index)}><span className="service-number">{number}</span><span className="service-title">{title}</span><span className="service-description">{description}</span><span className="service-plus">{activeService === index ? <ArrowUpRight size={17} /> : <Plus size={17} />}</span></button>)}</div><div className="service-stage" aria-hidden="true"><AnimatePresence mode="wait"><motion.div className={`service-visual service-visual-${activeService}`} key={activeService} initial={{ opacity: 0, rotate: -12, scale: 0.85 }} animate={{ opacity: 1, rotate: 0, scale: 1 }} exit={{ opacity: 0, rotate: 12, scale: 1.05 }} transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}><div className="service-visual-core" /><div className="service-visual-line line-a" /><div className="service-visual-line line-b" /><div className="service-visual-line line-c" /><span>{['Think', 'Make', 'Shape', 'Grow'][activeService]}</span></motion.div></AnimatePresence><div className="stage-caption">Every detail is a design decision.</div></div></div>
        </section>

        <section className="studio-section" id="studio"><div className="studio-object" aria-hidden="true"><div className="studio-sphere" /><motion.img className="studio-photo" src="/manus-storage/async-images/N2fAAVE3ZrFsPJPy3XfG05/image-3.webp" alt="Designy Outlet creative studio process" initial={{ opacity: 0, rotate: 7, y: 35 }} whileInView={{ opacity: 0.9, rotate: 0, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }} /><div className="studio-orbit orbit-a" /><div className="studio-orbit orbit-b" /><div className="studio-orbit orbit-c" /></div><div className="studio-content"><Reveal><p className="kicker light">The studio / India + everywhere</p></Reveal><Reveal delay={0.08}><h2>Built for brands<br /><span>ready to be seen.</span></h2></Reveal><Reveal delay={0.16}><p className="studio-copy">Designy Outlet began with a graphic designer bringing ideas to life one project at a time. Today, we shape identities, posters and digital experiences with a belief that great design should be felt before it is explained.</p></Reveal><Reveal delay={0.24}><button className="outline-button" onClick={() => scrollTo('contact')}>Start a conversation <ArrowUpRight size={15} /></button></Reveal></div><div className="studio-index">02 / 06</div></section>

        <section className="credibility-section section-paper"><Reveal><p className="kicker">The capabilities behind the work</p></Reveal><div className="client-row">{capabilities.map((capability, index) => <span key={capability} className={`client-logo client-${index}`}>{capability}</span>)}</div><div className="quote-wrap"><span className="quote-mark">“</span><Reveal><blockquote>Clear thinking.<br />Sharp design.<br /><i>Lasting identity.</i></blockquote></Reveal><div className="quote-meta"><span>Our mission</span><span>Designy Outlet</span></div></div></section>

        <section className="contact-section section-coral" id="contact"><div className="contact-shape shape-a" /><div className="contact-shape shape-b" /><div className="contact-top"><p className="kicker">Ready to stand out?</p><span>Let’s make it memorable.</span></div><div className="contact-content"><Reveal><h2>Let’s build<br /><i>something bold.</i></h2></Reveal><Reveal delay={0.1} className="contact-copy"><p>Tell us what you are making. We’ll bring the visual thinking, craft and art direction to help it stand out.</p></Reveal>{sent ? <motion.div className="sent-message" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}><Sparkles size={20} /><div><strong>Nice. It’s on its way.</strong><span>We’ll be in touch within a couple of days.</span></div></motion.div> : <form className="inquiry-form" onSubmit={(event) => { event.preventDefault(); setSent(true) }}><label><span>Your name</span><input required type="text" placeholder="Your name" /></label><label><span>Work email</span><input required type="email" placeholder="you@company.com" /></label><label className="full-field"><span>What are we making?</span><textarea required rows={1} placeholder="A new identity, a poster series, a digital world..." /></label><button className="submit-button" type="submit">Ready to stand out <Send size={16} /></button></form>}</div><div className="contact-footer"><a href="mailto:designyoutlet.india@gmail.com">designyoutlet.india@gmail.com</a><span>+91 6206919461 · +91 98043 76420</span><span><a href="https://www.instagram.com/designy_outlet/" target="_blank" rel="noreferrer">Instagram</a> · <a href="https://www.linkedin.com/company/designy-outlet/" target="_blank" rel="noreferrer">LinkedIn</a></span></div></section>
      </main>

      <footer className="footer section-ink"><div className="footer-logo">designy<span> outlet.</span></div><div className="footer-note">A graphic design studio<br />for brands with something to say.</div><button onClick={replayIntro} className="replay-intro">Replay intro <ArrowUpRight size={15} /></button><button onClick={() => scrollTo('top')} className="back-top">Back to top <ArrowUpRight size={15} /></button></footer>
    </div>
  )
}

export default App
